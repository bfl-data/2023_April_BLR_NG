export const environment = {
    production: true,
    postsUrl: 'https://www.bajaj.com/posts'
};