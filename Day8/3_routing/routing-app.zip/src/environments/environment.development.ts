export const environment = {
    production: false,
    usersUrl: 'http://localhost:8000/api/users',
    accountUrl: 'http://localhost:8000/account/getToken',
    productsUrl: 'http://localhost:8000/api/products'
};