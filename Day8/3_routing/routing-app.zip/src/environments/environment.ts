export const environment = {
    production: false,
    usersUrl: 'http://www.bajaj.com/api/users',
    accountUrl: 'http://www.bajaj.com/account/getToken',
    productsUrl: 'http://www.bajaj.com/api/products'
};