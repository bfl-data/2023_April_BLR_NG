import { inject } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivateFn, RouterStateSnapshot } from "@angular/router";
import { AuthenticatorService } from "../authenticator.service";
import { Router } from "@angular/router";

export const CanActivateAdminGuard: CanActivateFn =
  (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => {

    const router = inject(Router);
    const authenticatorService = inject(AuthenticatorService);

    if (authenticatorService.getToken())
      return true;
    else {
      router.navigate(['login'], { queryParams: { returnUrl: state.url } });
      return false;
    }
  }