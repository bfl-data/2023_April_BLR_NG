import { Component } from '@angular/core';
import { Employee } from 'src/app/models/employee.model';

@Component({
  selector: 'employee-root',
  templateUrl: './employee-root.component.html'
})
export class EmployeeRootComponent {
  employee: Employee = { employeeID: 1, name: "", designation: "", salary: 0 };
  employees: Employee[] = [];
  edit: boolean = false;
  details: boolean = false;

  saveEmployee(employee: Employee) {
    if (this.edit) {
      var temp_employees = [...this.employees];
      var itemIndex = temp_employees.findIndex(e => e.employeeID === employee.employeeID);
      temp_employees.splice(itemIndex, 1, { ...employee });
      this.employees = [...temp_employees];
      this.refreshState();
    } else if (this.details) {
      return;
    } else {
      this.employees = [...this.employees, { ...employee }];
      this.refreshState();
    }
  }

  private refreshState() {
    this.employee = { employeeID: this.getNextId(this.employees), name: "", designation: "", salary: 0 };
    this.edit = false;
    this.details = false;
  }

  private getNextId(employees: Employee[]) {
    return employees.length ? employees[employees.length - 1].employeeID + 1 : 1;
  }

  selectEmployee(args: { details: boolean, edit: boolean, employee: Employee }) {
    this.details = args.details;
    this.edit = args.edit;
    this.employee = { ...args.employee };
  }

  removeEmployee(id: number) {
    this.employees = [...this.employees.filter(item => item.employeeID !== id)]
    this.refreshState();
  }
}
