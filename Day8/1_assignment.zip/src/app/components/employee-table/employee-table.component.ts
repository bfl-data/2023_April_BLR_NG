import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Employee } from 'src/app/models/employee.model';

@Component({
  selector: 'employee-table',
  templateUrl: './employee-table.component.html'
})
export class EmployeeTableComponent {
  @Input() employees?: Array<Employee>;
  @Output() onSelect: EventEmitter<{ details: boolean, edit: boolean, employee: Employee }>;
  @Output() onDelete: EventEmitter<number>;

  constructor() {
    this.onSelect = new EventEmitter<{ details: boolean, edit: boolean, employee: Employee }>();
    this.onDelete = new EventEmitter<number>();
  }

  showMessage(id: number) {
    if(window.confirm("Are you sure you want to delete the record?"))
      this.onDelete.emit(id);
  }
}
