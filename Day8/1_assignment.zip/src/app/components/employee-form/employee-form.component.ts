import { Component, EventEmitter, Input, Output, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Employee } from 'src/app/models/employee.model';

@Component({
  selector: 'employee-form',
  templateUrl: './employee-form.component.html',
  styles: [
  ]
})
export class EmployeeFormComponent {
  @Input() employee?: Employee;
  @Output() onSave: EventEmitter<Employee>;

  employeeForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.employeeForm = this.fb.group({
      employeeID: ['', [Validators.required, Validators.pattern(/^\d+$/)]],
      name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
      designation: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
      salary: ['', [Validators.required, Validators.pattern(/^\d+$/)]],
    });

    this.onSave = new EventEmitter<Employee>();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['employee']) {
      this.employee = changes['employee'].currentValue;
      this.employeeForm.reset(changes['employee'].currentValue);
    }
  }

  ngOnInit() {
    if (this.employee)
      this.employeeForm.setValue(this.employee);
  }

  onSubmit() {
    if (this.employeeForm.invalid) {
      this.employeeForm.markAllAsTouched();
      return;
    }

    const employee = this.formGroupToEmployee(this.employeeForm.value);
    this.onSave.emit(employee);
  }

  reset() {
    if (this.employee)
      this.employeeForm.reset(this.employee);
  }

  private formGroupToEmployee(formValue: any): Employee {
    const employee: Employee = {
      employeeID: formValue.employeeID,
      name: formValue.name,
      designation: formValue.designation,
      salary: formValue.salary
    };
    return employee;
  }
}
