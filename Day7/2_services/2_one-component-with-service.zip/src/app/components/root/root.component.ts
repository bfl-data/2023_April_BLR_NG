import { Component, Inject, OnInit } from '@angular/core';
import { Author } from 'src/app/models/author.interface';
import { AuthorFactory } from 'src/app/services/author-factory.service';
import { AuthorsService } from 'src/app/services/authors.service';
import { AUTHORS_NEW_TOKEN, AUTHORS_TOKEN } from 'src/app/services/custom-di-token';
import { env } from 'src/data/env-data';

@Component({
    selector: 'app-root',
    templateUrl: './root.component.html',
    styleUrls: ['./root.component.css'],
    providers: [
        // { provide: 'Authors', useValue: authorList }
        // { provide: AUTHORS_TOKEN, useValue: authorList }

        // { provide: AUTHORS_NEW_TOKEN, useExisting: AUTHORS_TOKEN }
        // { provide: AuthorsService, useClass: AuthorsService }
        // AuthorsService
        // NAuthorsService

        { provide: 'ENVIORNMENT', useValue: env },
        {
            provide: AuthorsService,
            useFactory: AuthorFactory,
            deps: [
                'ENVIORNMENT'
            ]
        }
    ]
})
export class RootComponent implements OnInit {
    list?: Array<Author>;
    selectedAuthor?: Author;

    // constructor(@Inject('Authors') private authors: Array<Author>) { }
    // constructor(@Inject(AUTHORS_TOKEN) private authors: Array<Author>) { }
    // constructor(@Inject(AUTHORS_NEW_TOKEN) private authors: Array<Author>) { }

    constructor(private authorsService: AuthorsService) { }

    // constructor(private authorsService: NAuthorsService) { }

    ngOnInit() {
        // this.list = this.authors;

        this.list = this.authorsService.Authors;
    }

    selectAuthor(a: Author) {
        this.selectedAuthor = a;
    }

    isSelected(a: Author) {
        return this.selectedAuthor === a;
    }
}