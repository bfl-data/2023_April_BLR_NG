import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css']
})
export class RootComponent {
  flag = false;
  myStyles = {
    'background-color': 'green',
    'font-size': '20px',
    'color': 'white'
  };
  name = "";

  addName() {
    this.name = "Bajaj"
  }

  removeName() {
    this.name = "";
  }

  root_div_click() {
    alert("Root Div Click Handler....");
  }
}
