import { Component } from '@angular/core';

@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styles: [
  ]
})
export class ListComponent {
  personList: Array<string>;
  selected!: string;

  constructor() {
    this.personList = ["Shantanu", "Shubhangi", "Kunal", "Amit", "Dinesh", "Nur", "Piyush", "Ashwin"];
  }

  select(person: string, e: Event) {
    this.selected = person;
    e.preventDefault();
  }

  btn_click(e: Event) {
    alert("Button Clicked....");
    e.stopPropagation();
  }

  div1_click() {
    // alert("Dive One Clicked....");
  }

  div2_click() {
    // alert("Div Two Clicked....");
  }

  div3_click() {
    // alert("Div Three Clicked....");
  }
}
