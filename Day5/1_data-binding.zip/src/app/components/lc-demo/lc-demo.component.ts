import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-lc-demo',
  template: `
    <p>
      lc-demo works!
    </p>
  `,
  styles: [
  ]
})
export class LcDemoComponent {
  @Input() data?: string;

  constructor() {
    console.log("Constructor Executed...");
  }

  ngOnChanges() {
    console.log("ngOnChanges Executed...");
  }

  ngOnInit() {
    console.log("ngOnInit Executed...");
  }

  ngDoCheck() {
    console.log("ngDoCheck Executed...");
  }

  ngAfterContentInit() {
    console.log("ngAfterContentInit Executed...");
  }

  ngAfterContentChecked() {
    console.log("ngAfterContentChecked Executed...");
  }

  ngAfterViewInit() {
    console.log("ngAfterViewInit Executed...");
  }

  ngAfterViewChecked() {
    console.log("ngAfterViewChecked Executed...");
  }

  ngOnDestroy() {
    console.log("ngOnDestroy Executed...");
  }
}
