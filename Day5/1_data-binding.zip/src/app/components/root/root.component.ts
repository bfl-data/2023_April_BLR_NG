import { AfterViewInit, Component, NgZone } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent implements AfterViewInit {
  message: string;
  flag: boolean;
  h: number;
  w: number;
  greetings: string;
  name!: string;
  count: number;
  show: boolean;

  constructor(private ngZone: NgZone) {
    this.message = "Hello World!";
    this.flag = false;
    this.h = 200;
    this.w = 200;
    this.greetings = "Hello";
    this.count = 0;
    this.show = false;

    // setInterval(() => {
    //   this.message = new Date().toLocaleTimeString();
    // }, 1000);
  }

  showHide() {
    this.show = !this.show;
  }

  ngAfterViewInit(): void {
    // document.getElementById("btnJS")?.addEventListener("click", () => {
    //   this.message = new Date().toLocaleTimeString();
    // });

    this.ngZone.runOutsideAngular(() => {
      document.getElementById("btnJS")?.addEventListener("click", () => {
        this.message = new Date().toLocaleTimeString();
        console.log(this.message);
      });
    });
  }

  doChange() {
    this.message = new Date().toLocaleTimeString();
  }

  anchorClick1() {
    this.message = new Date().toLocaleTimeString();
  }

  anchorClick2(e: Event) {
    this.message = new Date().toLocaleTimeString();
    e.preventDefault();
  }

  doUpdate(n: string) {
    this.greetings = `Hello, ${n}`;
    console.log("doUpdate called...");
  }

  incrementCount(cb: () => void) {
    this.count += 1;
    if (this.count < 50) {
      window.setTimeout(() => {
        this.incrementCount(cb);
      }, 100);
    } else {
      cb();
    }
  }

  inZone() {
    this.count = 0;
    this.message = "Started...";
    this.incrementCount(() => {
      this.message = "Completed....";
    });
  }

  outOfZone() {
    this.count = 0;
    this.message = "Started...";
    this.ngZone.runOutsideAngular(() => {
      this.incrementCount(() => {
        this.ngZone.run(() => {
          this.message = "Completed....";
        });
      });
    });
  }
}
