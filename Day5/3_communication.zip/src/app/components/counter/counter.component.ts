import { Component, Input } from '@angular/core';

@Component({
  selector: 'counter',
  templateUrl: './counter.component.html'
})
export class CounterComponent {
  @Input() interval: number;
  flag: boolean;
  count: number;
  clickCount: number;

  constructor() {
    this.flag = false;
    this.count = 0;
    this.interval = 1;
    this.clickCount = 0;
  }

  manageClickCount() {
    this.clickCount += 1;
    if (this.clickCount > 9) {
      this.flag = true;
    }
  }

  inc() {
    this.count += this.interval;
    this.manageClickCount();
  }

  dec() {
    this.count -= this.interval;
    this.manageClickCount();
  }

  reset() {
    this.flag = false;
    this.count = 0;
    this.clickCount = 0;
  }
}
