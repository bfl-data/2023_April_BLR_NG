// function hello1() {
//     console.log("Hello World 1!");
// }

// const hello2 = function () {
//     console.log("Hello World 2!");
// }

// const hello3 = new Function('console.log("Hello World 3!");');

// const hello4 = () => {
//     console.log("Hello World 4!");
// }

// hello1();
// hello2();
// hello3();
// hello4();

// ------------------------------------

var i = 10;
console.log(i);
console.log(typeof i);

var f = function() {
    console.log("Hello");
}
console.log(f);
console.log(typeof f);

// Function is a type in JavaScript, which can refer to a block of code
// Function Pointers
// Delegates

// Can we create a variable of type number
// Yes; you can create a variable of type function also

// Can we create a variable of type number inside a function
// Yes; you can create a variable of type function inside a function also (nested Functions)

// function f1() {
//     function f2() {

//     }
// }


// Can we return a variable of type number from a function
// Yes; you can return a variable of type function from a function also (Closures, Fn Cyrrying, HOF)

// function f1() {
//     function f2() {

//     }

//     return f2;
// }


// Can we pass a variable of type number to a function
// Yes; you can pass a variable of type function to a function also (Callbacks)

document.getElementById("b1").addEventListener("click", function() {});

setInterval(function(){}, 1000);