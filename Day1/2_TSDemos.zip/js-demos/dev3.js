var dev1;

(function (ns) {
    function check() {
        console.log("Hello from File Three");
    }

    ns.check = check;
})(dev1 = dev1 || {});