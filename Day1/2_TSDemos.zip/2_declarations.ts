// Variables created in TypeScript are optionally typesafe
// Untyped Variable - Not TypeSafe, we will not get any intellisense on an untyped variable (any)

// var data;
// data = 10;
// data = "Manish";

// var data: any;
// data = 10;
// data = "Manish";

// Implicitly Typed - Type Inference
// var data = 10;
// // data = "Manish";                // Type 'string' is not assignable to type 'number'.
// data = 10.5;
// data = 0b1001;
// data = 0o1001;
// data = 0x1001;

// var ename = "Manish";
// ename = 10;                      //Type 'number' is not assignable to type 'string'

// Exlicitly Typed

// var age: number;
// age = 20;
// // age = "abc";                        // Type 'string' is not assignable to type 'number'.

// var s: string;

// Fn to add 2 numbers
// function add(x, y) {
//     if ((typeof x == "number") && (typeof y == "number"))
//         return x + y;
//     else
//         throw new TypeError("Invalid Arguments...");
// }

// function add(x: any, y: any) {
//     if ((typeof x == "number") && (typeof y == "number"))
//         return x + y;
//     else
//         throw new TypeError("Invalid Arguments...");
// }

function add(x: number, y: number) {
    return x + y;
}

console.log(add(2, 3));
// console.log(add(2, "abc"));
// console.log(add("abc", "xyz"));
// console.log(add("abc", true));

// Lefthand side of assignment operatir, all JS types can be used (declaration)
// number / string / boolean / undefined / array / object / Date / RegExp / function / void
// any
// All the new types which are supported by the latest version of ECMASCRIPT

var a: Array<number>;
var s: Symbol;
var p: Promise<number>;

// Righthand side of assignment operator, API's (Functions or Types) will come
// If you want to use any API, You can only use them with proper configuration
// Based on target in tsconfig.json
// And lib section configured in your tsconfig.json

a = new Array();
s = Symbol("Hello");
p = new Promise((resolve, reject) => { });

// VS Code gives you intellisense using d.ts files (Type Definition Files)
