var d1: number;
d1 = 10;

var d2: string;
d2 = "Manish";

var d3: number | string;
d3 = 10;
d3 = "abc";

var d4: number | string | boolean;
d4 = 10;
d4 = "abc";
d4 = true;

type myType =  number | string | boolean;

var d5:myType;
d5 = 10;
d5 = "abc";
d5 = true;