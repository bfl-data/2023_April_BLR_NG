// Type assertion is a mechanism which tells the compiler about the type of a variable. 
// Type assertion is explicitly telling the compiler that we want to treat the entity as a different type.

var data1: any = "Hello, I am a string";

console.log(data1);
console.log(typeof data1);

// console.log(data1.toUppercase());
// console.log(data1.toUpperCase());

console.log((<string>data1).toUpperCase());
console.log((data1 as string).toUpperCase());

var arr = [10, 20, 30, 40, [50, 60]];

(arr[4] as number[])[0] = 5000;

console.log(arr);

// console.log((data1 as number).toFixed());
