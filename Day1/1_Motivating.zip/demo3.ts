class EmployeeT {
    constructor(private _name: string) { }

    getName() {
        return this._name;
    }

    setName(value: string) {
        this._name = value;
    }
}

var e1 = new EmployeeT("Manish");
console.log(e1.getName());
e1.setName("Abhijeet");
console.log(e1.getName());

var e2 = new EmployeeT("Subodh");
console.log(e2.getName());
e2.setName("Ramakant");
console.log(e2.getName());

console.log(e1);
console.log(e2);

// 136 bytes (68 bytes per instance)