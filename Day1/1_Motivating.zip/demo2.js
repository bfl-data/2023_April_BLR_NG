console.log("Demo Two...");

const Employee = (function () {
    function Employee(name) {
        this._name = name;
    }

    Employee.prototype.getName = function () {
        return this._name;
    }

    Employee.prototype.setName = function (value) {
        this._name = value;
    }

    return Employee;
})();

var e1 = new Employee("Manish");
console.log(e1.getName());
e1.setName("Abhijeet");
console.log(e1.getName());

var e2 = new Employee("Subodh");
console.log(e2.getName());
e2.setName("Ramakant");
console.log(e2.getName());

console.log(e1);
console.log(e2);

// 136 bytes (68 bytes per instance)