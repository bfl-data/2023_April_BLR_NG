var EmployeeT = /** @class */ (function () {
    function EmployeeT(_name) {
        this._name = _name;
    }
    EmployeeT.prototype.getName = function () {
        return this._name;
    };
    EmployeeT.prototype.setName = function (value) {
        this._name = value;
    };
    return EmployeeT;
}());
var e1 = new EmployeeT(10);
console.log(e1.getName());
e1.setName("Abhijeet");
console.log(e1.getName());
var e2 = new EmployeeT("Subodh");
console.log(e2.getName());
e2.setName("Ramakant");
console.log(e2.getName());
console.log(e1);
console.log(e2);
// 136 bytes (68 bytes per instance)
