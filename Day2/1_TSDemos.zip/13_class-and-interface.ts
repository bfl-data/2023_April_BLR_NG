// // interface IPerson {
// //     name: string;
// //     age: number;
// //     greet(message: string): string;
// // }

// // class Person implements IPerson {
// //     constructor(public name: string, public age: number) { }

// //     greet(message: string): string {
// //         return "Hello";    
// //     }
// // }

// // let p1: IPerson = new Person("Abhijeet", 40);
// // let p2: IPerson = new Person("Ramakant", 41);

// // console.log(p1.greet("Hi"));
// // console.log(p2.greet("Hi"));

// // ------------------------------------------------- Multiple Interface Implementations

// // interface IPerson {
// //     name: string;
// //     age: number;
// //     greet(message: string): string;
// // }

// // interface IEmployee {
// //     doWork(): string;
// // }

// // class Person implements IPerson, IEmployee {
// //     constructor(public name: string, public age: number) { }

// //     greet(message: string): string {
// //         return "Hello";
// //     }

// //     doWork(): string {
// //         return "I am learning TypeScript";
// //     }
// // }

// // let p1: Person = new Person("Abhijeet", 40);
// // console.log(p1.greet("Hi"));
// // console.log(p1.doWork());

// // // ------------------------------------------------- Inerface Extraction

// // interface IPerson {
// //     name: string;
// //     age: number;
// //     greet(message: string): string;
// // }

// // interface IEmployee {
// //     doWork(): string;
// // }

// // interface ICustomer {
// //     doShopping(): string;
// // }

// // class Person implements IPerson, IEmployee, ICustomer {
// //     constructor(public name: string, public age: number) { }

// //     greet(message: string): string {
// //         return "Hello";
// //     }

// //     doWork(): string {
// //         return "I am learning TypeScript";
// //     }

// //     doShopping(): string {
// //         return "Let us do it online";
// //     }
// // }

// // // let p1: Person = new Person("Abhijeet", 40);
// // // console.log(p1.greet("Hi"));
// // // console.log(p1.doWork());
// // // console.log(p1.doShopping());

// // let p1: IPerson = new Person("Abhijeet", 40);
// // console.log(p1.greet("Hi"));

// // let p2: IEmployee = new Person("Abhijeet", 40);
// // console.log(p2.doWork());

// // let p3: ICustomer = new Person("Abhijeet", 40);
// // console.log(p3.doShopping());


// // ------------------------------------------------- Interface can extend other interface(s)

// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string): string;
// }

// interface IEmployee extends IPerson {
//     doWork(): string;
// }

// interface ICustomer extends IPerson {
//     doShopping(): string;
// }

// class Person implements IPerson, IEmployee, ICustomer {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning TypeScript";
//     }

//     doShopping(): string {
//         return "Let us do it online";
//     }
// }

// let p2: IEmployee = new Person("Abhijeet", 40);
// console.log(p2.greet("Hi"));
// console.log(p2.doWork());

// let p3: ICustomer = new Person("Abhijeet", 40);
// console.log(p3.greet("Hi"));
// console.log(p3.doShopping());

// ------------------------------------------------ Interface can extend from class(es)
class Control {
    get ControlId(): number {
        return 10;
    }

    focus(): string {
        return "The control is in focus....";
    }
}

class SelectableControl {
    select(): string {
        return "the control is selected....";
    }
}

// When an interface extends a class, it extends only the class members but not 
// their implementation because interfaces don’t contain implementations.
interface ISelectableControl extends Control, SelectableControl {}

class Button implements ISelectableControl
{
    get ControlId(): number {
        throw new Error("Method not implemented.");
    }
    focus(): string {
        throw new Error("Method not implemented.");
    }
    select(): string {
        throw new Error("Method not implemented.");
    }

}
// class Developer {
//     applyLeave() { }
// }

// class PM {
//     approveLeave() { }
// }

// class DevPM extends Developer, PM {

// }

// // --------------------

// class Cashier {
//     applyLoan() {}
// }

// class BM {
//     approveLoan() {}

//     signOffLoan() {}
// }

// class CashMan extends Cashier, BM {

// }

// class CM {
//     applyLoan() {}

//     approveLoan() {}

//     signOffLoan() {}
// }