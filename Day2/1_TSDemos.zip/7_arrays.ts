// var empList: Array<number>;
// var empList: number[];

// var empList: Array<{ id: number, name: string, city: string }>;

// empList = [
//     { id: 1, name: "Manish", city: "Pune" },    
//     { id: 2, name: "Ramakant", city: "Delhi" },
//     { id: 3, name: "Abhijeet", city: "Pune" },
//     { id: 4, name: "Subodh", city: "Mumbai" },
//     { id: 5, name: "Abhishek", city: "Mathura" }
// ];

// empList.push({ id: 6, name: "Amit", city: "Pune" });

// ----------------------------------------------------------- Type Alieas
// type Employee = { id: number, name: string, city: string };

// var empList: Array<Employee>;

// empList = [
//     { id: 1, name: "Manish", city: "Pune" },
//     { id: 2, name: "Ramakant", city: "Delhi" },
//     { id: 3, name: "Abhijeet", city: "Pune" },
//     { id: 4, name: "Subodh", city: "Mumbai" },
//     { id: 5, name: "Abhishek", city: "Mathura" }
// ];

// empList.push({ id: 6, name: "Amit", city: "Pune" });

// // delete empList[3];

// // Array Iteration
// // for (let i = 0; i < empList.length; i++) {
// //     console.log(`${i}               ${JSON.stringify(empList[i])}`);
// // }

// // for(const item of empList) {
// //     console.log(`${JSON.stringify(item)}`);
// // }

// // console.log(empList);

// // empList.forEach((item, index) => {
// //     console.log(`${index}               ${JSON.stringify(item)}`);
// // });

// // for (const item of empList.entries()) {
// //     console.log(`${JSON.stringify(item)}`);
// // }

// for (const [index, item] of empList.entries()) {
//     console.log(`${index}               ${JSON.stringify(item)}`);
// }