function hello(name) {
    console.log("Hello,", name);
}

hello("Manish");
hello(10);
hello();
hello("Manish", "Pune");