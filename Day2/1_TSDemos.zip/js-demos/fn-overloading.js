function hello() {
    console.log("Hello World!");
}

function hello(name) {
    console.log(`Hello ${name}`);
}

hello();
hello("Manish");