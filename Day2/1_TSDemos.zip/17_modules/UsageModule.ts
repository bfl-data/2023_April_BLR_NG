import { Point, IPoint } from './PointModule';

let point: IPoint = new Point(2, 3);
console.log(point.getDistance());
