// function hello() {
//     console.log("Hello World!");
// }

// var r = hello();
// console.log(r);
// console.log(typeof r);

// var r1: undefined;
// // r1 = 10;            // Type '10' is not assignable to type 'undefined'.
// r1 = undefined;
// console.log(r1);

// var r2: void;
// // r2 = 10;            // Type 'number' is not assignable to type 'void'.
// // r2 = void 0;
// r2 = undefined;
// console.log(r2);

// var r3: never;
// // r3 = 10;                // Error: Type number is not assignable to type 'never'.
// // r3 = void 0;            // Error: Type undefined is not assignable to type 'never'.
// // r3 = undefined;         // Error: Type undefined is not assignable to type 'never'.
// console.log(r3);

// var r4: unknown;
// console.log(r4.trim());

// var r5: any;
// console.log(r5.trim());

// ---------------------------------

// function iterate(): never {
//     let i = 1;
//     while (true) {
//         console.log(++i);
//     }
// }

// iterate();
console.log("Last line in the file....");

// -----------------------------------------
// let filter1: (arg: unknown, by: unknown) => unknown;
// filter1 = function (arg: string[], by: string): string[] {
//     return arg.filter(n=>n.startsWith(by));
// }

// let filter2: (arg: any, by: any) => any;
// filter2 = function (arg: string[], by: string): string[] {
//     return arg.filter(n=>n.startsWith(by));
// }

// let filter1: (arg: unknown, by: unknown) => unknown;
// filter1 = function (arg, by) {
//     return arg.filter(n => n.startsWith(by));
// }

// let filter2: (arg: any, by: any) => any;
// filter2 = function (arg, by) {
//     return arg.filter(n => n.startsWith(by));
// }