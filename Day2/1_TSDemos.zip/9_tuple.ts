// TypeGuard Array

var dataArr1: (number | string)[];
dataArr1 = [1, "Manish"];
dataArr1 = ["Manish", 1];
dataArr1 = ["Manish", "Abhijeet"];
dataArr1 = [1, 2];
dataArr1 = [1, 2, 3, 4, 5, 6];
dataArr1 = [1, "Manish", "Pune", 411021];

// Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence
let dataRow: [number, string];
dataRow = [1, "Manish"];
// dataRow = ["Manish", 1];
// dataRow = ["Manish", "Abhijeet"];
// dataRow = [1, 2];
// dataRow = [1, 2, 3, 4, 5, 6];
// dataRow = [1, "Manish", "Pune", 411021];

for (const data of dataRow) {
    console.log(data);
}