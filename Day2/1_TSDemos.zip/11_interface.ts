// // const area = function (rect: { h: number, w?: number }) {
// //     return rect.h * rect.w;
// // }

// // let s1 = { h: 20, w: 10 };
// // console.log(area(s1));

// // let s2 = { h: 20, w: 10, d: 30 };
// // console.log(area(s2));

// // let s3 = { h: 20, d: 30 };
// // console.log(area(s3));

// // // -----------------------------------------------------
// // type Shape = {
// //     h: number,
// //     w?: number
// // };

// // const area = function (rect: Shape) {
// //     return rect.h * rect.w;
// // }

// // let s1: Shape = { h: 20, w: 10 };
// // console.log(area(s1));

// // // let s2: Shape = { h: 20, w: 10, d: 30 };
// // // console.log(area(s2));

// // // let s3: Shape = { h: 20, d: 30 };
// // // console.log(area(s3));

// // ----------------------------------------------------- Interface
// // interface IShape {
// //     h: number;
// //     w?: number;
// // }

// // const area = function (rect: IShape) {
// //     return rect.h * rect.w;
// // }

// // let s1: IShape = { h: 20, w: 10 };
// // console.log(area(s1));

// // let s2: IShape = { h: 20, w: 10, d: 30 };
// // console.log(area(s2));

// // let s3: IShape = { h: 20, d: 30 };
// // console.log(area(s3));

// // ----------------------------------------------------- Interface
// // interface IPerson {
// //     name: string,
// //     age: number;
// //     greet(message: string): string;
// // }

// // let p1: IPerson = {
// //     name: "Abhijeet",
// //     age: 40,
// //     greet: function (m) {
// //         return "Hello";
// //     }
// // };

// // let p2: IPerson = {
// //     name: "Ramakant",
// //     age: 41,
// //     greet: function (m) {
// //         return "Hola";
// //     }
// // };

// // console.log(p1.greet("Hi"));
// // console.log(p2.greet("Hi"));

// // type TPerson = {
// //     name: string,
// //     age: number,
// //     greet(message: string): string
// // }

// // let p3: TPerson = {
// //     name: "Subodh",
// //     age: 50,
// //     greet: function (m) {
// //         return "Hey";
// //     }
// // };

// // console.log(p3.greet("Hi"));


// // -------------------------------------------

// // type TShape = {
// //     height: number
// // }

// // type TShape = {
// //     width: number
// // }

// // interface IShape {
// //     height: number;
// // }

// // interface IShape {
// //     width: number
// // }

// // let s1: IShape = { height: 20, width: 10 };

// // ----------------------------------------

// interface ICustomer {
//     doShopping(): string;
// }

// interface IEmployee {
//     doWork(): string;
// }

// // Union (TypeGuard)
// type ICustomerOrIEmployee = ICustomer | IEmployee;

// var person1: ICustomerOrIEmployee;

// person1 = {
//     doShopping(): string {
//         return "Shopping Online";
//     }
// };

// // Intersection

// type ICustomerAndIEmployee = ICustomer & IEmployee;

// var person2: ICustomerAndIEmployee;

// person2 = {
//     doShopping(): string {
//         return "Shopping Online";
//     },
//     doWork(): string {
//         return "Learning TypeScript";
//     }
// };