import { Component, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { CounterComponent } from '../counter/counter.component';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css']
})
export class RootComponent {
  pList: Array<string>;

  @ViewChild("c1", { static: true })
  counter_one?: CounterComponent;

  @ViewChild("c2", { static: true })
  counter_two?: CounterComponent;

  @ViewChildren(CounterComponent)
  counters?: QueryList<CounterComponent>;

  message: string;

  constructor() {
    this.pList = ["Shantanu", "Shubhangi", "Kunal", "Amit", "Dinesh", "Nur", "Piyush", "Ashwin"];
    this.message = "";
  }

  p2_reset(counter: CounterComponent) {
    counter.reset();
  }

  p3_reset() {
    // console.log(this.counter_one);
    this.counter_one?.reset();
    this.counter_two?.reset();
  }

  reset_all() {
    if (this.counters) {
      for (const counter of this.counters) {
        counter.reset();
      }
    }
  }

  updateMessage(flag: boolean) {
    if (flag)
      this.message = "Max Click Reached, please Reset to restart";
    else
      this.message = "";
  }
}
