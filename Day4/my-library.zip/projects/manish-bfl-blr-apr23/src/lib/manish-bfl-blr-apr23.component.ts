import { Component } from '@angular/core';

@Component({
  selector: 'lib-manish-bfl-blr-apr23',
  template: `
    <h4 class="text-info">
      Manish BFL Library Works
    </h4>
  `,
  styles: [
  ]
})
export class ManishBflBlrApr23Component {

}
