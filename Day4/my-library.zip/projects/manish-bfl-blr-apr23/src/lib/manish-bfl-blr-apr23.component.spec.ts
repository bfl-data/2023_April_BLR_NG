import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManishBflBlrApr23Component } from './manish-bfl-blr-apr23.component';

describe('ManishBflBlrApr23Component', () => {
  let component: ManishBflBlrApr23Component;
  let fixture: ComponentFixture<ManishBflBlrApr23Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManishBflBlrApr23Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManishBflBlrApr23Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
