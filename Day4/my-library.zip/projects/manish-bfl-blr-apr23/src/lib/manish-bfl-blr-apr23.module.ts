import { NgModule } from '@angular/core';
import { ManishBflBlrApr23Component } from './manish-bfl-blr-apr23.component';



@NgModule({
  declarations: [
    ManishBflBlrApr23Component
  ],
  imports: [
  ],
  exports: [
    ManishBflBlrApr23Component
  ]
})
export class ManishBflBlrApr23Module { }
