import { TestBed } from '@angular/core/testing';

import { ManishBflBlrApr23Service } from './manish-bfl-blr-apr23.service';

describe('ManishBflBlrApr23Service', () => {
  let service: ManishBflBlrApr23Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ManishBflBlrApr23Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
