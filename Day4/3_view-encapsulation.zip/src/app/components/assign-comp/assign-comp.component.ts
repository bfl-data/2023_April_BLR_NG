import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-assign-comp',
  template: `
    <style>
      body {
        margin: 100px;
        background-color: lightgreen;
      }
    </style>
    <p>
      assign-comp works!
    </p>
  `,
  encapsulation: ViewEncapsulation.None
})
export class AssignCompComponent {

}
