import { Component } from '@angular/core';

@Component({
  selector: 'app-assign-two',
  templateUrl: './assign-two.component.html',
  styles: [
  ]
})
export class AssignTwoComponent {

}
