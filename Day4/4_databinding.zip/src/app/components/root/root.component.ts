import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent {
  message: string;
  flag: boolean;
  h: number;
  w: number;
  greetings: string;
  name!: string;

  constructor() {
    this.message = "Hello World!";
    this.flag = false;
    this.h = 200;
    this.w = 200;
    this.greetings = "Hello";

    // setInterval(() => {
    //   this.message = new Date().toLocaleTimeString();
    // }, 1000);
  }

  doChange() {
    this.message = new Date().toLocaleTimeString();
  }

  anchorClick1() {
    this.message = new Date().toLocaleTimeString();
  }

  anchorClick2(e: Event) {
    this.message = new Date().toLocaleTimeString();
    e.preventDefault();
  }

  doUpdate(n:string) {
    this.greetings = `Hello, ${n}`;
    console.log("doUpdate called...");
  }
}
