import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <app-comp-one></app-comp-one>
    <app-comp-two></app-comp-two>
    <hr>
    <app-comp-one></app-comp-one>
    <app-comp-two></app-comp-two>
    <hr>
    <app-comp-one></app-comp-one>
    <app-comp-two></app-comp-two>
  `
})
export class RootComponent {

}
