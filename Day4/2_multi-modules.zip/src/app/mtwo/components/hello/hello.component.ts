import { Component } from '@angular/core';

@Component({
  selector: 'app-hello',
  template: `
    <h2 class="text-primary">
      Hello from Module Two
    </h2>
  `
})
export class HelloComponent {

}
