import { Component } from '@angular/core';

@Component({
  selector: 'app-hello',
  template: `
    <h2 class="text-success">
      Hello from Module One
    </h2>
  `
})
export class HelloComponent {

}
