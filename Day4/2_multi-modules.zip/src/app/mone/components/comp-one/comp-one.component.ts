import { Component } from '@angular/core';

@Component({
  selector: 'app-comp-one',
  template: `
    <h2 class="text-success">
      Hello from Component One Module One
    </h2>
    <app-hello></app-hello>
    <app-scomp></app-scomp>
  `
})
export class CompOneComponent {

}
