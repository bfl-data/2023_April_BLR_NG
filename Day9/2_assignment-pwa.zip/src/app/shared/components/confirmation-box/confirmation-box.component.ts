import { Component, OnInit } from '@angular/core';
import { ConfirmDialogService } from '../../services/confirm-dialog.service';

@Component({
  selector: 'confirmation-box',
  templateUrl: './confirmation-box.component.html'
})
export class ConfirmationBoxComponent implements OnInit {
  message: any;

  constructor(private confirmDialogService: ConfirmDialogService) { }

  ngOnInit(): void {
    this.confirmDialogService.getMessage().subscribe(message => {
      this.message = message;
    });
  }
}
