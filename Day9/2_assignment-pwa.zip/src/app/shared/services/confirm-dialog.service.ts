import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable()
export class ConfirmDialogService {
  private subject = new Subject<any>();

  confirm(message: string, yesFn: () => void, noFn: () => void): any {
    this.setConfirmation(message, yesFn, noFn);
  }

  private setConfirmation(message: string, yesFn: () => void, noFn: () => void): any {
    const self = this;
    this.subject.next({
      type: 'confirm',
      text: message,
      yesFn(): any {
        self.subject.next("");
        yesFn();
      },
      noFn(): any {
        self.subject.next("");
        noFn();
      }
    });
  }

  getMessage(): Observable<any> {
    return this.subject.asObservable();
  }
}
