import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfirmationBoxComponent } from './components/confirmation-box/confirmation-box.component';
import { ConfirmDialogService } from './services/confirm-dialog.service';

@NgModule({
  declarations: [
    ConfirmationBoxComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    ConfirmationBoxComponent
  ],
  providers: [
    ConfirmDialogService
  ]
})
export class SharedModule { }
