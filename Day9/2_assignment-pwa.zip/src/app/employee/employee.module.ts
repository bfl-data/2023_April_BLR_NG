import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EmployeeFormComponent } from './components/employee-form/employee-form.component';
import { EmployeeTableComponent } from './components/employee-table/employee-table.component';
import { EmployeeRootComponent } from './components/employee-root/employee-root.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [
    EmployeeFormComponent,
    EmployeeTableComponent,
    EmployeeRootComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule
  ],
  exports: [
    EmployeeRootComponent
  ]
})
export class EmployeeModule { }
