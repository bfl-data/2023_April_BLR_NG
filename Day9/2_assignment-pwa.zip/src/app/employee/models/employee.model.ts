export interface Employee {
    employeeID: number;
    name: string;
    designation: string;
    salary: number;
}
