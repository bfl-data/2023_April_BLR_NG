import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Employee } from '../../models/employee.model';
import { ConfirmDialogService } from 'src/app/shared/services/confirm-dialog.service';

@Component({
  selector: 'employee-table',
  templateUrl: './employee-table.component.html'
})
export class EmployeeTableComponent {
  @Input() employees?: Array<Employee>;
  @Output() onSelect: EventEmitter<{ details: boolean, edit: boolean, employee: Employee }>;
  @Output() onDelete: EventEmitter<number>;

  constructor(private confirmDialogService: ConfirmDialogService) {
    this.onSelect = new EventEmitter<{ details: boolean, edit: boolean, employee: Employee }>();
    this.onDelete = new EventEmitter<number>();
  }

  showMessage(id: number) {
    this.confirmDialogService.confirm("Are you sure you want to delete?", () => {
      this.onDelete.emit(id);
    }, () => {
      return;
    });
  }
}
