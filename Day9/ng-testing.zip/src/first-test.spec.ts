// describe('my first test', () => {
//     let sut: any;       // System Under Test

//     beforeEach(() => {
//         sut = {
//             call: function (n: number) {
//                 return n.toString();
//             }
//         };
//     });

//     it('should be true if true', () => {
//         // A - Arrange
//         var a = 10;

//         // A - Act / Action
//         var result = sut.call(a);

//         // A - Assert
//         expect(result).toBe("10");
//     });
// });

describe('my first test', () => {
    let sut: any;       // System Under Test

    beforeEach(() => {
        sut = {};
    });

    it('should be true if true', () => {
        // A - Arrange
        sut.a = false;

        // A - Act / Action
        sut.a = true;

        // A - Assert
        expect(sut.a).toBe(true);
    });
});