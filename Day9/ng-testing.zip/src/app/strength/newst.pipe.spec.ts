import { NewstPipe } from './newst.pipe';

describe('NewstPipe', () => {
  it('create an instance', () => {
    const pipe = new NewstPipe();
    expect(pipe).toBeTruthy();
  });

  it('should return string 10 when number 10 is passed', () => {
    const pipe = new NewstPipe();
    expect(pipe.transform(10)).toEqual("10");
  });

  it('should return string 20 when number 20 is passed', () => {
    const pipe = new NewstPipe();
    expect(pipe.transform(20)).toEqual("20");
  });
});
