import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'newst'
})
export class NewstPipe implements PipeTransform {

  transform(value: number, ...args: unknown[]): string {
    return value.toString();
  }

}
