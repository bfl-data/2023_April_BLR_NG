import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CrudRootComponent } from './components/crud-root/crud-root.component';
import { ProductsService } from './services/products.service';
import { PubSubService } from './services/pub-sub.service';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CrudAddEditComponent } from './components/crud-add-edit/crud-add-edit.component';

@NgModule({
  declarations: [
    CrudRootComponent,
    CrudAddEditComponent
  ],
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule
  ],
  providers: [
    ProductsService,
    PubSubService
  ],
  exports: [
    CrudRootComponent,
    CrudAddEditComponent
  ]
})
export class CrudModule { }
