import { Component } from "@angular/core";

@Component({
    selector: 'app-hello',
    template: `
        <div>
            <h1 class="red">Hello World!</h1>
            <h1 class="text-primary">Hello World!</h1>
            <h1 class="text-success">
                Activity <span class="bi bi-activity"></span>
            </h1>
            <h1 class="text-success">
                Activity <span class="bi bi-airplane-engines"></span>
            </h1>
        </div>
    `
})
export class HelloComponent { }